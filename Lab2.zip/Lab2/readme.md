# who did what

## Jayden
- Activity Swapping and intent passing

## Jasmine
- Detail Activity

## Emily
- Item datatype

## Ada
- Making Recyclerview

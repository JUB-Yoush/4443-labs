package com.example.lab3;

public class TodoItem {
    private String title;
    private String description;
    private String deadline;

    public TodoItem(String title, String description, String deadline) {
        this.title = title;
        this.description = description;
        this.deadline = deadline;
    }
}

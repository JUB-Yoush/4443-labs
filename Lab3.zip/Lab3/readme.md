# architecture

We use the model view controller architecture. We have a seperation of functions for the widgets that render data, as well as the buttons that interface with the activities. The other buttons interface with the database designed through the shared preferences.  

## who did what

### Jayden

- Database and views set up

### Jasmine

- Dateview set up

### Emily

- Form View setup

### Ada

- Bugfixing

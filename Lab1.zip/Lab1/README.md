# who did what

## Jayden

- Registration Activity, Reading and writing to users file

## Jasmine

- Login system, bugfixes with checkboxes

## Emily

- arranging the views, making sure they are relative to each other
- checkboxes

## Ada

- welcome activity
- cancel button
